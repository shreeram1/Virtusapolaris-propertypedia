package com.example.sreevishnu.ex8;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements LocationListener{

    TextView txtLat, txtLong, txtAlt;
    LocationManager manager;
    Location location;
    String provider;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtLat = (TextView)findViewById(R.id.txtLat);
        txtLong = (TextView)findViewById(R.id.txtLong);
        txtAlt = (TextView)findViewById(R.id.txtAlt);
        manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        provider = LocationManager.GPS_PROVIDER;
        try {
            location = manager.getLastKnownLocation(provider);
            manager.requestLocationUpdates(provider, 0, 0, this);

        }
        catch (SecurityException e)
        {

        }

        if (location != null)
        {         onLocationChanged(location);
        }
        else
            Toast.makeText(this, "Location cannot be accessed", Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onLocationChanged(Location location) {
        txtLat.setText(Double.toString(location.getLatitude()));
        txtLong.setText(Double.toString(location.getLongitude()));
        txtAlt.setText(Double.toString(location.getAltitude()));

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
